qdarkstyle.\_\_main\_\_ module
==============================

.. automodule:: qdarkstyle.__main__
   :members:
   :undoc-members:
   :show-inheritance:
