Known Issues
============

Combo Box
---------

Describe the problem, add some images and code.
